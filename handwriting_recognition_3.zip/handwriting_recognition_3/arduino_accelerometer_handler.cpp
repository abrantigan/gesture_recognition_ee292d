/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "accelerometer_handler.h"

#include <Arduino.h>
#include <Arduino_LSM9DS1.h>

#include "constants.h"

#define ACTIVATED LOW
int recordButton = 2;
// A buffer holding 400 sets of 3-channel values
float save_data[length] = {0.0};
// Most recent position in the save_data buffer
int begin_index = 0;
bool char_started = false;

TfLiteStatus SetupAccelerometer(tflite::ErrorReporter* error_reporter) {
  // Wait until we know the serial port is ready
  while (!Serial) {
  }

  // Switch on the IMU
  if (!IMU.begin()) {
    error_reporter->Report("Failed to initialize IMU");
    return kTfLiteError;
  }

  // Determine how many measurements to keep in order to
  // meet kTargetHz
//  float sample_rate = IMU.accelerationSampleRate();
//  sample_every_n = static_cast<int>(roundf(sample_rate / kTargetHz));

  error_reporter->Report("Write!");

  return kTfLiteOk;
}

bool ReadAccelerometer(tflite::ErrorReporter* error_reporter, float* input,
                       int length, bool reset_buffer) {
  // Clear the buffer if required, e.g. after a successful prediction
  if (reset_buffer) {
    memset(save_data, 0, length * sizeof(float));
    begin_index = 0;
  }
  // Keep track of whether we stored any new data
  bool char_finished = false;
  // Loop through new samples and add to buffer
  while (IMU.accelerationAvailable()) {
    int buttonVal = digitalRead(recordButton);
    if (buttonVal == ACTIVATED) {
      float x, y, z;
      // Read each sample, removing it from the device's FIFO buffer
      if (!IMU.readAcceleration(x, y, z)) {
        error_reporter->Report("Failed to read data");
        break;
      }
      // Write samples to our buffer
      save_data[begin_index++] = x;
      save_data[begin_index++] = y;
      save_data[begin_index++] = z;
      if (begin_index == length) {
        char_finished = true;
        begin_index = 0;
        break;
      }
    } else if (begin_index > 50) {
      // if enough data collected and button no longer pressed, character is finished
      char_finished = true;
      begin_index = 0;
      break;
    } else {
      // button was pressed and released but not enough data collected to be a character so reset index
      begin_index = 0;
    }
  }

  // Skip this round if data is not ready yet
  if (!char_finished) {
    return false;
  }

  // Copy the requested number of bytes to the provided input tensor
  for (int i = 0; i < length; ++i) {
    input[i] = save_data[i];
  }

  return true;
}
